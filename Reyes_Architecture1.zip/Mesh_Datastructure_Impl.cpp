#include <iostream>
#include "Mesh_Datastructure_Impl.h"

mesh_datastructure::mesh_datastructure()
{
    //hardcode zeros to all the 400 vertices
    //todo - find a way to dynamically initialize the number of vertices
    for (int vertex_index = 0; vertex_index < 16; vertex_index++)
    {
        v[vertex_index] << 0, 0, 0;
    }
}

void mesh_datastructure::setVertex(int ind, Eigen::Vector3f ver) { v[ind] = ver; }

void mesh_datastructure::printVertex()
{
    for (int vertex_index = 0; vertex_index < 16; vertex_index++)
    {
        std::cout << v[vertex_index];
    }
}