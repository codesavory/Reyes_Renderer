#pragma once
#include <Eigen/Eigen>

class mesh_datastructure
{
public:
	Eigen::Vector3f v[16];//hardcoded 100 points

	mesh_datastructure();

	void setVertex(int ind, Eigen::Vector3f ver);
	void printVertex();

	/*each points values*/
	//Eigen::Vector3f color[3];
	//Eigen::Vector2f tex_coordinates[3];
	//Eigen::Vector3f normal[3];
};