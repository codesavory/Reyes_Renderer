#include <iostream>
#include <atlimage.h>
#include "Transformations_Impl.h"
#include "Mesh_Datastructure_Impl.h"
#include <Eigen/Eigen>

const double PI = 3.141592653589793238462643383279502884197;
#define EPSILON 0.000001

float check_float_epsilon(float input_float)
{
    if (input_float < EPSILON)
        return 0.;
    return input_float;
}

auto to_vec4(const Eigen::Vector3f& v3, float w = 1.0f)
{
    return Eigen::Vector4f(v3.x(), v3.y(), v3.z(), w);
}

int print_image()
{
    //create the model
    mesh_datastructure sphere;//update the vertex coordinates

    //transform
    Eigen::Vector3f eye_pos = { 0, 0, 0 };
    float angle = 0;
    Eigen::Matrix4f mvp = get_projection_matrix(45, 1, 0.1, 50) * get_view_matrix(eye_pos) * get_model_matrix(angle, 'z');
                                   //eye_fov,aspect_ratio,zNear,zFar
    
    //to view space - covert from 3d coordinates to uv coordinates
    // in  - VERTEX center                 : defines the center of the sphere, all points will be offset from this
    // in  - double r                      : defines the radius of the sphere
    // out - vector<VERTEX> & spherePoints : vector containing the points of the sphere
    // Iterate through phi, theta then convert r,theta,phi to  XYZ
    Eigen::Vector3f center(0, 0, 0);
    double r=5;
    int index_of_points = 0;
    for (double phi = 0.; phi < 2 * PI; phi += PI / 2.) // Azimuth [0, 2PI]
    {
        for (double theta = 0.; theta < PI; theta += PI / 4.) // Elevation [0, PI]
        {
            Eigen::Vector3f point;
            point[0] = check_float_epsilon(r * cos(phi) * sin(theta) + center.x());
            point[1] = check_float_epsilon(r * sin(phi) * sin(theta) + center.y());
            point[2] = check_float_epsilon(r * cos(theta) + center.z());
            //spherePoints.push_back(point);
            cout <<"Point"<<index_of_points<<":"<< point << endl;
            sphere.setVertex(index_of_points++, point);//calculates a vertex for each phase discretized
        }
    }

    //to learn: should I map these coordinates to [1,1]T before scaling it to image resolution?
    /*cout << endl<<"Sphere Coordinates:";
    sphere.printVertex();

    //to device/image space
    int width = 100;
    int height = 100;
    float f1 = (100 - 0.1) / 2.0;
    float f2 = (100 + 0.1) / 2.0;
    for (int sphere_coordinates = 0; sphere_coordinates < 16; sphere_coordinates++)
    {
        Eigen::Vector4f v = mvp * to_vec4(sphere.v[sphere_coordinates],1.0f);//write respective getters for easier access
        v /= v.w();
        v.x()= 0.5 * width * (v.x() + 1.0);
        v.y() = 0.5 * height * (v.y() + 1.0);
        v.z() = v.z() * f1 + f2;
        cout << "v" << sphere_coordinates <<":" <<v<<endl;
    }*/

    for (int sphere_coordinates = 0; sphere_coordinates < 16; sphere_coordinates++)
    {
        Eigen::Vector4f v = mvp * to_vec4(sphere.v[sphere_coordinates], 1.0f);//write respective getters for easier access
        cout << "image space" << sphere_coordinates << ":" << v;
    }

    /*//write to image
    CImage bitmapzor;
    bitmapzor.Create(100, 100, 24);

    COLORREF PixColor = 0; //This is a color data
    int R = 0, G = 0, B = 0; //These are the channel values

    //First we shall for instance allter all pixel colors to green using standard way
    for (int i = 0; i < bitmapzor.GetWidth(); i++) //along line
        for (int j = 0; j < bitmapzor.GetHeight(); j++) //new line
        {
            //default colors
            int R = 250;
            int G = 200;
            int B = 200;

            // if pixel is in a diagonal, set it as green
            if (i == j) {
                R = 0; B = 0; G = 100;
            }


            PixColor = RGB(R, G, B);
            bitmapzor.SetPixel(i, j, PixColor);
        }

    bitmapzor.Save(_T("D:\\CG_Source\\CS285\\HW-1\\Reyes_Architecture1\\test2.jpg"), Gdiplus::ImageFormatJPEG);*/

    //Now we need to save this result to a HD:
    //LPCTSTR filename = _T("D:\\CG_Source\\CS285\\HW - 1\\Reyes_Architecture1\\test2.bmp");
    //you can change the location of this file
    //bitmapzor.Save(filename);
    //sgetchar();


    // using pure byte array. actual bytesream stuff


    /*
    //Okay now another way with the pointer arithmetics:
    printf("Pointer arithmetics demo (without GetPixel and SetPixel functions): \n");
    bitmapzor.Destroy(); //Unload the changed bitmap from memory
    bitmapzor.Load("C:\\1.bmp");
    //this is a pointer to the exact bitmap pixel color array location
    BYTE* byteptr = (BYTE*)bitmapzor.GetBits();

    //You can use other functions for HBITMAP and HGDIOBJ methods to find out the
    //container for bitmap color table.
    //For instance when you use GDI and HBITMAPS, you should use
    //BYTE* byteptr = (BYTE*)(HBITMAPINFOHEADER + HBITMAPINFOHEADER->biSize);
    //simple pointer arithmetics

    int pitch = bitmapzor.GetPitch(); //This is a pointer offset to get new line of the bitmap

    for (int i = 0; i < bitmapzor.GetWidth(); i++)
        for (int j = 0; j < bitmapzor.GetHeight(); j++)
        {
            //pointer arithmetics to find (i,j) pixel colors:
            R = *(byteptr + pitch * j + 3 * i);
            G = *(byteptr + pitch * j + 3 * i + 1);
            B = *(byteptr + pitch * j + 3 * i + 2);

            //allter pixel G color:
            G = (int)((float)G * 1.3);
            if (G > 255) G = 255;
            //write down the new G-Color
            *(byteptr + pitch * j + 3 * i + 1) = G;
        }

    //Save the bitmap:
    LPCTSTR filename2 = _T("C:\\ptrarithm.bmp"); //you can use any other file name
    bitmapzor.Save(filename2);
    printf("Done, file is saved to: %s\n Please press any key to exit program", filename2);
    getchar();
    bitmapzor.Destroy(); //destroy the bitmap
    */
    return 0;
};